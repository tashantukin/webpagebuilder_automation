<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Collection of simple test cases</description>
   <name>Simple.Web Page Builder</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>28a509b2-35bc-49a0-8b5f-f073be04b7ae</testSuiteGuid>
   <testCaseLink>
      <guid>ca5cd6fd-d210-485a-a50c-19ad034922b9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Simple/17_button_create_new_page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9fc76151-7474-41de-9d55-98bb71ccaaac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Simple/42_button_cancel</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>976c0aab-fc08-4226-a351-41804741132d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Simple/43_button_save</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>37e54e27-dc0b-41f6-81af-674086204791</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Simple/41_button_preview</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
