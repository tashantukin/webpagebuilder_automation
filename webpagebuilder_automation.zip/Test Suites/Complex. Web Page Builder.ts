<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Complex. Web Page Builder</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>1c010875-af60-415a-9285-30094d9b9a86</testSuiteGuid>
   <testCaseLink>
      <guid>a9035fe2-914b-40b9-ac14-2b8a3b6ff0ab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Complex/Add a Page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fc81cfa4-7bda-4269-839a-5e87cdde21a7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Complex/Page Preview</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2f5fa019-1b7f-44db-abab-1527c6765e42</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Complex/Delete Page</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
